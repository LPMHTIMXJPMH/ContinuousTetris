import cv2 as cv
import numpy as np
import math

import methods as methods
import sample as sample
import distance as distance

where_to_draw =  np.zeros( [ 1080, 1920 ,3], dtype = np.uint8 )

def findCnt(src):
    contours, _ = cv.findContours(src, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
    return contours


def contour_property(idx,contours,threshold,board_box):
    selected_cnt = []
    for cnt in contours:
        area = int(cv.contourArea(cnt))
        if area > threshold[0] and area < threshold[1]:
            selected_cnt.append(cnt)
            methods.draw(where_to_draw, selected_cnt, obv = 4)

    num = len(selected_cnt)
    print("\n", num, "counter detected.", "\n")

    # Draw Board
    if num == 1 and threshold[0] > 10000:

        def board_direction(corners):
            left_bottom_to_top = [t - b for t, b in zip(corners['left_top'],corners['left_bottom'])]
            right_bottom_to_top = [t - b for t, b in zip(corners['right_top'],corners['right_bottom'])]
            top_minus_bottom = [xy / 2 for xy in [left + right for left, right in zip(left_bottom_to_top, right_bottom_to_top)]]
            print('board direction vector(top_minus_bottom) is : ', top_minus_bottom)
            return top_minus_bottom

        selected_cnt = selected_cnt[0]
        contours_poly = cv.approxPolyDP(selected_cnt, 3, True)
        minRec = cv.minAreaRect(contours_poly)
        box = cv.boxPoints(minRec)
        box = np.int0(box)
        print('  Board box coordinates: \n', box)
        for b in box:
            methods.draw_text(where_to_draw, str(b), (b[0]-20,b[1]))
        methods.draw(where_to_draw, [box],(225,75,225),2)
        corners = methods.rect_corner(box)
        board_vector = board_direction(corners)
        block_size = sample.board_sample(where_to_draw, corners, 10, 14)
        box_left_bottom = corners['left_bottom']
        print("Board Location point = {}".format(box_left_bottom))
        return corners, block_size, board_vector
    elif num > 0:
        # Analyse contours
        CL= bb(idx, selected_cnt, board_box)
    else:
        print("Error! No object Contour detected!")
        return
        
    return CL


def bb(idx, contours, board_coordinates):
    idx = idx
    # We instore all tetris block piece class in the ClassList below!
    cls = distance.Distances(where_to_draw, board_coordinates)
    print("Analysing Rectangle:")
    for i, c in enumerate(contours):
        contours_poly = cv.approxPolyDP(c, 3, True)

        boundRect = cv.boundingRect(contours_poly)
        cv.rectangle(where_to_draw,(boundRect[0],boundRect[1]), \
        (boundRect[0]+boundRect[2],boundRect[1]+boundRect[3]),(0,125,255),2)

        minRec = cv.minAreaRect(contours_poly)
        (___, __), (width, height), angle = minRec
        cls.angle.append(angle)
        box = cv.boxPoints(minRec)
        box = np.int0(box)
        for b in box:
            methods.draw_text(where_to_draw, str(b), (b[0] - 26, b[1]))
        diff = width - height
        if diff > 0:
            big = width
            small = height
        else:
            diff = -diff
            big = height
            small = width
        index = None
        if  diff > 2 * small and diff < 4 * small:
            index = 4
            cls.minRec(box)
            cls.grab()
            sorted_box = sorted(box, key = lambda x:x[0])
            if abs(sorted_box[0][1] - sorted_box[1][1]) < 0.1:
                sum_x = 0
                sum_y = 0
                for i in range(4):
                    for ii in range(4):
                        if i != ii:
                            sum_x += abs(box[i][0] - box[ii][0])
                            sum_y += abs(box[i][1] - box[ii][1])
                if sum_x > sum_y:
                    cls.direction.append('x')
                    cls.angle[-1] = 90
                else:
                    cls.direction.append('y')
                    cls.angle[-1] = 0
            else:
                direction = None
                middle1 = (box[0] + box[1]) / 2
                middle2 = (box[1] + box[2]) / 2
                middle3 = (box[2] + box[3]) / 2
                middle4 = (box[3] + box[0]) / 2
                dist1 = np.linalg.norm(middle1-middle3)
                dist2 = np.linalg.norm(middle2-middle4)
                if abs(dist1) > abs(dist2):
                    cross1 = middle1
                    cross2 = middle3
                else:
                    cross1 = middle2
                    cross2 = middle4
                angle = math.atan2(cross2[1] - cross1[1], cross2[0] - cross1[0]) * 180 / np.pi
                cls.angle[-1] = angle
        elif big / small <= 1.3 and big / small > 0.77:
            index = 0
            direction = None
            cls.minRec(box)
            cls.grab()
        elif big / small < 1.8:
            index, direction, center, vector = sample.sample(where_to_draw, box, cnt = c)
            cls.xy.append((int(center[0]), int(center[1])))
            cls.vector.append(vector)
            cls.grab()
        cls.index.append(index)
        if index is not None:
            cls.direction.append(direction)
            cls.draw()
            methods.draw(where_to_draw, [box],(125,175,25),2)
        else:
            cls.direction.append(None)
            methods.draw(where_to_draw, [box],(225,255,225),4)
            print("Failed to find the shape Index!")            
        if index != idx:
            cls.angle.pop()
            cls.index.pop()
            cls.xy.pop()
            cls.direction.pop()
            cls.distance.pop()
    return cls