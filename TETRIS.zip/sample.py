
import numpy as np
import cv2 as cv

import block_array as block_array

def vec(head, center):
    return [h - c for h, c in zip(head, center)]


def board_sample(img, box, width, height):
    left_top_right_top = np.array(box['right_top']) - np.array(box['left_top'])
    left_top_left_bottom = np.array(box['left_bottom']) - np.array(box['left_top'])

    right_bottom_left_bottom = np.array(box['right_bottom']) - np.array(box['left_bottom'])
    right_bottom_right_top = np.array(box['right_bottom']) - np.array(box['right_top'])
 
    d1 = np.sqrt(np.square(left_top_right_top[0]) + np.square(left_top_right_top[1]))
    d2 = np.sqrt(np.square(left_top_left_bottom[0]) + np.square(left_top_left_bottom[1]))
    d3 = np.sqrt(np.square(right_bottom_left_bottom[0]) + np.square(right_bottom_left_bottom[1]))
    d4 = np.sqrt(np.square(right_bottom_right_top[0]) + np.square(right_bottom_right_top[1]))

    block_size = (d1 + d2 + d3 + d4)/(2*(width + height))
    assert block_size is not None, print('board corners distance : ', d1, d2, d3, d4)
    line_color = (100,150,200)
    # avoid divided by zero
    if abs(left_top_right_top[1]) > 0.01 and \
        abs(left_top_left_bottom[0]) > 0.01 and \
        abs(right_bottom_left_bottom[1]) > 0.01 and \
        abs(right_bottom_right_top[0]) > 0.01: 

        x_bias = ((left_top_left_bottom[0] + right_bottom_right_top[0])/2)/height
        dy = ((left_top_left_bottom[1] + right_bottom_right_top[1])/2)/height

        dx = ((left_top_right_top[0] + right_bottom_left_bottom[0])/2)/width
        y_bias = ((left_top_right_top[1] + right_bottom_left_bottom[1])/2)/width
        for i in range(height+1):
            cv.line(img, (int(box['left_top'][0]+i*x_bias), int(box['left_top'][1]+i*dy)), (int(box['right_top'][0]+i*x_bias), int(box['right_top'][1]+i*dy)), line_color, 2)
        for i in range(width+1):
            cv.line(img, (int(box['left_top'][0]+i*dx), int(box['left_top'][1]+i*y_bias)), (int(box['left_bottom'][0]+i*dx), int(box['left_bottom'][1]+i*y_bias)), line_color, 2)
        cv.imshow('Drawing Borad', img)
        cv.waitKey()
    else:
        block_size = int(block_size)
        left_x = int(box['left_top'][0])
        right_x = int(box['right_top'][0])
        top_y = int(box['left_top'][1])
        bottom_y = int(box['left_bottom'][1])
        for i in range(height+1):
            cv.line(img, (left_x, top_y+i*block_size), (right_x, top_y+i*block_size), line_color, 2)
        for i in range(width+1):
            cv.line(img, (left_x+i*block_size, top_y), (left_x+i*block_size, bottom_y), line_color, 2)
        cv.imshow('Drawing Borad', img)
        cv.waitKey()
    return block_size

def sample(img, box, cnt = None):
    sorted_box = sorted(box, key = lambda x: x[0])
    if abs(sorted_box[0][0] - sorted_box[1][0]) > 0.01: 
        dist1 = np.linalg.norm(box[0]-box[1])
        dist2 = np.linalg.norm(box[0]-box[3])

        length = 2
        if dist1 > dist2:
            grid = np.zeros((2, 3, 5, 5, 2))

            D = ((box[3][1] - box[0][1])/2 + (box[1][0] - box[0][0])/3)/2
            d = D/4
            r = (box[0] + box[3]) / 2
            c = (box[1] - box[0]) / 3
            c1 = box[0] + c
            c2 = box[0] + 2 * c
            cv.circle(img, (int(r[0]), int(r[1])), 4, (125,175,25),-1)
            cv.circle(img, (int(c1[0]), int(c1[1])), 4, (125,175,25),-1)
            cv.circle(img, (int(c2[0]), int(c2[1])), 4, (125,175,25),-1)

            # x
            grid[0, 0, ..., 0, 0] = np.arange(box[0][0], r[0] + 1e-3, (r[0] - box[0][0])/4)
            grid[1, 0, ..., 0, 0] = np.arange(r[0], box[3][0] + 1e-3, (box[3][0] - r[0])/4)

            for _ in range(4):
                grid[0, 0, ..., _+1, 0] = grid[0, 0, ..., _, 0] + d
                grid[1, 0, ..., _+1, 0] = grid[1, 0, ..., _, 0] + d
            for _ in range(3 - 1):
                grid[0, _ + 1, ..., 0] = grid[0, _, ..., 0] + D
                grid[1, _ + 1, ..., 0] = grid[1, _, ..., 0] + D
            # y
            grid[0, 0, 0, :, 1] = np.arange(box[0][1], c1[1] - 1e-3, (c1[1] - box[0][1])/4)
            grid[0, 1, 0, :, 1] = np.arange(c1[1], c2[1] - 1e-3, (c1[1] - box[0][1])/4)
            grid[0, 2, 0, :, 1] = np.arange(c2[1], box[1][1] - 1e-3, (c1[1] - box[0][1])/4)
            for _ in range(4):
                grid[0, 0, _+1, ..., 1] = grid[0, 0, _, ..., 1] + d
                grid[0, 1, _+1, ..., 1] = grid[0, 1, _, ..., 1] + d
                grid[0, 2, _+1, ..., 1] = grid[0, 2, _, ..., 1] + d
            for _ in range(2 - 1):
                grid[_ + 1, ..., 1] = grid[_, ..., 1] + D

            for b in box:
                cv.circle(img, (b[0], b[1]), 1, (125,75,25),-1)
                cv.putText(img, str(b[0]) + ' ' + str(b[1]), (b[0], b[1]), cv.FONT_HERSHEY_SIMPLEX, \
                    fontScale = 0.3, color = (125,125,125), thickness = 1, lineType = cv.LINE_AA)
            counter = 0
            color = [255, 255, 255]
            for i,g in enumerate(grid):
                for ii,h in enumerate(g):
                        for i in h:
                            for j in i:
                                if counter < 50:
                                    color[1] -= 10
                                elif counter < 150:
                                    color[2] -= 20
                                elif counter < 300:
                                    color[0] -= 30                                                                                              
                                cv.circle(img, (int(j[0]), int(j[1])), 1, (color[0], color[1], color[2]), -1)
                            counter += 1
        else:
            length = 3
            grid = np.zeros((3, 2, 5, 5, 2))
            D = ((box[3][1] - box[0][1])/3 + (box[1][0] - box[0][0])/2)/2
            d = D/4
            r = (box[3] - box[0]) / 3
            r1 = box[0] + r
            r2 = box[0] + 2 * r
            c = (box[1] + box[0]) / 2
            cv.circle(img, (int(r1[0]), int(r1[1])), 4, (125,175,25),-1)
            cv.circle(img, (int(r2[0]), int(r2[1])), 4, (125,175,25),-1)
            cv.circle(img, (int(c[0]), int(c[1])), 4, (125,175,25),-1)

            # x
            grid[0, 0, ..., 0, 0] = np.arange(box[0][0], r1[0] + 1e-3, (r1[0] - box[0][0])/4)
            grid[1, 0, ..., 0, 0] = np.arange(r1[0], r2[0] + 1e-3, (r2[0] - r1[0])/4)
            grid[2, 0, ..., 0, 0] = np.arange(r2[0], box[3][0] + 1e-3, (box[3][0] - r2[0])/4)

            for _ in range(4):
                grid[0, 0, ..., _+1, 0] = grid[0, 0, ..., _, 0] + d
                grid[1, 0, ..., _+1, 0] = grid[1, 0, ..., _, 0] + d
                grid[2, 0, ..., _+1, 0] = grid[2, 0, ..., _, 0] + d
            
            for _ in range(2 - 1):
                grid[0, _ + 1, ..., 0] = grid[0, _, ..., 0] + D
                grid[1, _ + 1, ..., 0] = grid[1, _, ..., 0] + D
                grid[2, _ + 1, ..., 0] = grid[2, _, ..., 0] + D
            # y
            grid[0, 0, 0, :, 1] = np.arange(box[0][1], c[1] - 1e-3, (c[1] - box[0][1])/4)
            grid[0, 1, 0, :, 1] = np.arange(c[1], box[1][1] - 1e-3, (c[1] - box[0][1])/4)
            for _ in range(4):
                grid[0, 0, _+1, ..., 1] = grid[0, 0, _, ..., 1] + d
                grid[0, 1, _+1, ..., 1] = grid[0, 1, _, ..., 1] + d
            for _ in range(3 - 1):
                grid[_ + 1, ..., 1] = grid[_, ..., 1] + D

            for b in box:
                cv.circle(img, (b[0], b[1]), 1, (125,75,25),-1)
                cv.putText(img, str(b[0]) + ' ' + str(b[1]), (b[0], b[1]), cv.FONT_HERSHEY_SIMPLEX, \
                    fontScale = 0.3, color = (125,125,125), thickness = 1, lineType = cv.LINE_AA)
            counter = 0
            color = [255, 255, 255]
            for i,g in enumerate(grid):
                for ii,h in enumerate(g):
                        for i in h:
                            for j in i:
                                if counter < 50:
                                    color[1] -= 10
                                elif counter < 150:
                                    color[2] -= 20
                                elif counter < 300:
                                    color[0] -= 30                                                                                              
                                cv.circle(img, (int(j[0]), int(j[1])), 1, (color[0], color[1], color[2]), -1)
                            counter += 1
    else:
        dist1 = np.linalg.norm(box[0]-box[1])
        dist2 = np.linalg.norm(box[0]-box[3])

        length = 2
        if dist1 > dist2:
            grid = np.zeros((2, 3, 5, 5, 2))

            D = ((box[3][1] - box[0][1])/2 + (box[1][0] - box[0][0])/3)/2
            d = D/4
            r = (box[0] + box[3]) / 2
            c = (box[1] - box[0]) / 3
            c1 = box[0] + c
            c2 = box[0] + 2 * c
            cv.circle(img, (int(r[0]), int(r[1])), 4, (125,175,25),-1)
            cv.circle(img, (int(c1[0]), int(c1[1])), 4, (125,175,25),-1)
            cv.circle(img, (int(c2[0]), int(c2[1])), 4, (125,175,25),-1)


            # x
            grid[0, 0, ..., 0, 0] = np.array([box[0][0]]*5)
            grid[1, 0, ..., 0, 0] = np.array([box[0][0]]*5)

            for _ in range(4):
                grid[0, 0, ..., _+1, 0] = grid[0, 0, ..., _, 0] + d
                grid[1, 0, ..., _+1, 0] = grid[1, 0, ..., _, 0] + d
            for _ in range(3 - 1):
                grid[0, _ + 1, ..., 0] = grid[0, _, ..., 0] + D
                grid[1, _ + 1, ..., 0] = grid[1, _, ..., 0] + D

            # y
            grid[0, 0, 0, :, 1] = np.array([box[0][1]]*5)
            grid[0, 1, 0, :, 1] = np.array([box[0][1]]*5)
            grid[0, 2, 0, :, 1] = np.array([box[0][1]]*5)
            for _ in range(4):
                grid[0, 0, _+1, ..., 1] = grid[0, 0, _, ..., 1] + d
                grid[0, 1, _+1, ..., 1] = grid[0, 1, _, ..., 1] + d
                grid[0, 2, _+1, ..., 1] = grid[0, 2, _, ..., 1] + d
            for _ in range(2 - 1):
                grid[_ + 1, ..., 1] = grid[_, ..., 1] + D

            for b in box:
                cv.circle(img, (b[0], b[1]), 1, (125,75,25),-1)
                cv.putText(img, str(b[0]) + ' ' + str(b[1]), (b[0], b[1]), cv.FONT_HERSHEY_SIMPLEX, \
                    fontScale = 0.3, color = (125,125,125), thickness = 1, lineType = cv.LINE_AA)
            counter = 0
            color = [255, 255, 255]
            for i,g in enumerate(grid):
                for ii,h in enumerate(g):
                        for i in h:
                            for j in i:
                                if counter < 50:
                                    color[1] -= 10
                                elif counter < 150:
                                    color[2] -= 20
                                elif counter < 300:
                                    color[0] -= 30                                                                                              
                                cv.circle(img, (int(j[0]), int(j[1])), 1, (color[0], color[1], color[2]), -1)
                            counter += 1
        else:
            length = 3
            grid = np.zeros((3, 2, 5, 5, 2))
            D = ((box[3][1] - box[0][1])/3 + (box[1][0] - box[0][0])/2)/2
            d = D/4
            r = (box[3] - box[0]) / 3
            r1 = box[0] + r
            r2 = box[0] + 2 * r
            c = (box[1] + box[0]) / 2
            cv.circle(img, (int(r1[0]), int(r1[1])), 4, (125,175,25),-1)
            cv.circle(img, (int(r2[0]), int(r2[1])), 4, (125,175,25),-1)
            cv.circle(img, (int(c[0]), int(c[1])), 4, (125,175,25),-1)


            # x
            grid[0, 0, ..., 0, 0] = np.array([box[0][0]]*5)
            grid[1, 0, ..., 0, 0] = np.array([box[0][0]]*5)
            grid[2, 0, ..., 0, 0] = np.array([box[0][0]]*5)

            for _ in range(4):
                grid[0, 0, ..., _+1, 0] = grid[0, 0, ..., _, 0] + d
                grid[1, 0, ..., _+1, 0] = grid[1, 0, ..., _, 0] + d
                grid[2, 0, ..., _+1, 0] = grid[2, 0, ..., _, 0] + d
            
            for _ in range(2 - 1):
                grid[0, _ + 1, ..., 0] = grid[0, _, ..., 0] + D
                grid[1, _ + 1, ..., 0] = grid[1, _, ..., 0] + D
                grid[2, _ + 1, ..., 0] = grid[2, _, ..., 0] + D

            # y
            grid[0, 0, 0, :, 1] = np.array([box[0][1]]*5)
            grid[0, 1, 0, :, 1] = np.array([box[0][1]]*5)
            for _ in range(4):
                grid[0, 0, _+1, ..., 1] = grid[0, 0, _, ..., 1] + d
                grid[0, 1, _+1, ..., 1] = grid[0, 1, _, ..., 1] + d
            for _ in range(3 - 1):
                grid[_ + 1, ..., 1] = grid[_, ..., 1] + D

            for b in box:
                cv.circle(img, (b[0], b[1]), 1, (125,75,25),-1)
                cv.putText(img, str(b[0]) + ' ' + str(b[1]), (b[0], b[1]), cv.FONT_HERSHEY_SIMPLEX, \
                    fontScale = 0.3, color = (125,125,125), thickness = 1, lineType = cv.LINE_AA)
            counter = 0
            color = [255, 255, 255]
            for i,g in enumerate(grid):
                for ii,h in enumerate(g):
                        for i in h:
                            for j in i:
                                if counter < 50:
                                    color[1] -= 10
                                elif counter < 150:
                                    color[2] -= 20
                                elif counter < 300:
                                    color[0] -= 30                                                                                              
                                cv.circle(img, (int(j[0]), int(j[1])), 1, (color[0], color[1], color[2]), -1)
                            counter += 1
    block_center = [[0 for x in range(len(grid[0]))] for y in range(len(grid))]
    for r in range(len(grid)):
        for c in range(len(grid[0])):
            block_center[r][c] = grid[r][c][2][2]
    score = 0
    sample_result = []
    for _ in range(len(grid)):
        for __ in range(len(grid[_])):
            score = 0
            for ___ in range(3):
                for ____ in range(3):
                    if cv.pointPolygonTest(cnt, (grid[_,__][1+___][1+____][0],grid[_,__][1+___][1+____][1]),True) > 0:
                        score += 1
            sample_result.append(score)
    idx = sorted(np.argpartition(sample_result, -4)[-4:])
    idx = np.insert(idx, 0, length)
    idx = [x for x in idx]
    Index = None
    direction = 0
    for index, rotations in enumerate(block_array.real):
        if idx in rotations:
            Index = index
            if index == 0:
                Index = 1#T reverse
                if len(grid) == 3:
                    if idx[1] == 0:
                        direction = 4
                        center = block_center[1][0]
                        head = block_center[1][1]
                        vector = vec(head, center)
                        draw(center, img)
                        draw(head, img, 5)
                    else:
                        direction = 2
                        center = block_center[1][1]
                        head = block_center[1][0]
                        vector = vec(head, center)
                        draw(center, img)
                        draw(head, img, 5)
                if len(grid) == 2:
                    if idx[1] == 0:
                        direction = 3
                        center = block_center[0][1]
                        head = block_center[1][1]
                        vector = vec(head, center)
                        draw(center, img)
                        draw(head, img, 5)
                    else:
                        direction = 1
                        center = block_center[1][1]
                        head = block_center[0][1]
                        vector = vec(head, center)
                        draw(center, img)
                        draw(head, img, 5)

            if index == 1:
                Index = 2#Z
                if len(grid) == 3:
                    direction = 1
                    center = (block_center[1][0] + block_center[1][1])/2
                    head = (block_center[0][0] + block_center[0][1])/2
                    vector = vec(head, center)
                    draw(center, img)
                    draw(head, img, 5)
                if len(grid) == 2:
                    direction = 2
                    center = (block_center[0][1] + block_center[1][1])/2
                    head = (block_center[0][0] + block_center[1][0])/2
                    vector = vec(head, center)
                    draw(center, img)
                    draw(head, img, 5)

            if index == 2:
                Index = 3#S
                if len(grid) == 3:
                    direction = 1
                    center = (block_center[1][0] + block_center[1][1])/2
                    head = (block_center[0][0] + block_center[0][1])/2
                    vector = vec(head, center)
                    draw(center, img)
                    draw(head, img, 5)
                if len(grid) == 2:
                    direction = 2
                    center = (block_center[0][1] + block_center[1][1])/2
                    head = (block_center[0][0] + block_center[1][0])/2
                    vector = vec(head, center)
                    draw(center, img)
                    draw(head, img, 5)

            if index == 3:
                Index = 5#L
                if len(grid) == 3:
                    if idx[1] == 0 and idx[2] == 2:
                        direction = 1
                        center = block_center[2][0]
                        head = block_center[0][0]
                        vector = vec(head, center)
                        draw(center, img)
                        draw(head, img, 5)
                    elif idx[1] == 0 and idx[2] == 1:
                        direction = 3
                        center = block_center[0][1]
                        head = block_center[2][1]
                        vector = vec(head, center)
                        draw(center, img)
                        draw(head, img, 5)
                if len(grid) == 2:
                    if idx[1] == 2 and idx[2] == 3:
                        direction = 2
                        center = block_center[1][2]
                        head = block_center[1][0]
                        vector = vec(head, center)
                        draw(center, img)
                        draw(head, img, 5)
                    elif idx[1] == 0 and idx[2] == 1:
                        direction = 4
                        center = block_center[0][0]
                        head = block_center[0][2]
                        vector = vec(head, center)
                        draw(center, img)
                        draw(head, img, 5)

            if index == 4:
                Index = 6
                if len(grid) == 3:
                    if idx[1] == 1 and idx[2] == 3:
                        direction = 1
                        center = block_center[2][1]
                        head = block_center[0][1]
                        vector = vec(head, center)
                        draw(center, img)
                        draw(head, img, 5)
                    elif idx[1] == 0 and idx[2] == 1:
                        direction = 3
                        center = block_center[0][0]
                        head = block_center[2][0]
                        vector = vec(head, center)
                        draw(center, img)
                        draw(head, img, 5)
                if len(grid) == 2:
                    if idx[1] == 0 and idx[2] == 1:
                        direction = 2
                        center = block_center[0][2]
                        head = block_center[0][0]
                        vector = vec(head, center)
                        draw(center, img)
                        draw(head, img, 5)
                    elif idx[1] == 0 and idx[2] == 3:
                        direction = 4
                        center = block_center[1][0]
                        head = block_center[1][2]
                        vector = vec(head, center)
                        draw(center, img)
                        draw(head, img, 5)

    print('Index ', Index, '\nspin center ', center)
    return Index, direction, center, vector

# draw center x y
def draw(center, img, size = 10):
    cv.circle(img, (int(center[0]), int(center[1])), size, (255,255,255),-1)