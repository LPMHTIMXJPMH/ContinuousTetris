print(int('009'))
block_center = [[0 for x in range(3)] for y in range(2)]
print(block_center)