import pickle
import os.path
import numpy as np
import math
from scipy.misc import derivative

import tetris as tetris
import init as init
import methods
import block_array
import running
import Contours
src1 = Contours.where_to_draw
src2 = src1.copy()
shapes = running.shapes
for i in range(len(shapes)):
    print('shape in shapes: \n', shapes[i])
amount = 34

block_size = init.block_size
left_top = init.corners['left_top']
left_bottom = init.corners['left_bottom']
board_vector = init.board_vector
# check if correct from step 0 -> step 34
putted = [0]*7
ratio = (2.06, 2.01)









gone = os.path.isfile('save&reload/index_rotation_y_x.pickle') 
if not gone:
    import go as go
    go
    target = tetris.Tetris()
    print(f'target is {target}')

# sort steps by index and then y height
with open('index_rotation_y_x.pickle', 'rb') as f:
    steps = pickle.load(f)
print(type(steps))
#print(steps)


def rotate_vec(vec, rotation):
    x = vec[0]
    y = vec[1]
    x = math.cos(rotation) * x - math.sin(rotation) * y
    y = math.sin(rotation) * x + math.cos(rotation) * y
    return [x, y]
for i in range(amount):
    block_idx = steps[i][0]
    rotation = steps[i][1]
    order = putted[block_idx]
    current_block = shapes[block_idx]
    
    putted[block_idx] += 1 
    detected = len(current_block.xy)
    if detected > order:
        vector = rotate_vec(board_vector, rotation*90)
        print('target vector: ', vector)
        if current_block.vector:
            print('current vector: ', current_block.vector[order])
            angle = methods.vector_angle(vector,current_block.vector[order])
            print('two vector angle: ', angle / 3.1415926 * 180)







#######################
### <(￣︶￣)↗[GO!] ###
#######################
steps = np.array(sorted(steps, key = lambda x : (x[0], x[2])))
#print('steps after sorted by block piece index:\n', steps)

# left_top to spin center
centers = steps.copy().astype(float)
for i, step in enumerate(steps):
    idx = step[0]
    r = step[1]
    y = step[2]
    x = step[3]
    centers[i][2] = y + block_array.center[idx][r][0]
    centers[i][3] = x + block_array.center[idx][r][1]

#colors = [None]*amount
#for i in range(amount):
#    colors[i] = methods.random_color()














# turn programming distance into visual distance
def position(lefttop, rightbottom, y, x):
    derivative_x = (rightbottom[0] - lefttop[0]) / 10
    derivative_y = (rightbottom[1] - lefttop[1]) / 14
    y = lefttop[1] + derivative_y * y
    x = lefttop[0] + derivative_x * x
    return (y, x), (derivative_y, derivative_x)


for i in range(amount):
    y = centers[i][2]
    x = centers[i][3]
    block_idx = steps[i][0]
    rotation = steps[i][1]
    spin_center, derivative = position(left_top, init.corners['right_bottom'], y, x)
    centers[i][2] = spin_center[0]
    centers[i][3] = spin_center[1]












def pixel_to_milimeter(spin_center, ratio):
    x = spin_center[0]
    y = spin_center[1]

    x = x * ratio[0]
    y = y * ratio[1]

    return [x, y]

left_bottom = pixel_to_milimeter(left_bottom, ratio)
for i in range(amount):
    piece = block_array.pieces[block_idx]
    rotated = block_array.rotate(piece, rotation)
    r = len(rotated)
    c = len(rotated[0])
    print('\nblock on board spin center', [centers[i][2], centers[i][3]])

    order = putted[block_idx]
    current_block = shapes[block_idx]
    
    putted[block_idx] += 1 
    detected = len(current_block.xy)
    if detected > order:
        # 要放的位置的x、y坐标 spin_center
        # 当前位置的x、y坐标 current_block.xy[order]
        # delta1 -> 当前位置和棋盘左下角的x、y坐标距离
        print('current_block.xy[order]:', current_block.xy[order])
        print('current_block.x - spin_center', current_block.xy[order][0] - spin_center[0])
        print('current_block.y - spin_center', current_block.xy[order][1] - spin_center[1])
        delta_x = current_block.xy[order][0] - left_bottom[0]
        delta_y = current_block.xy[order][1] - left_bottom[1]
        delta1 = [delta_x, delta_y]
        milimeter_delta1 = pixel_to_milimeter(delta1, ratio)
        milimeter_current = pixel_to_milimeter(current_block.xy[order], ratio)
        delta2 = [current_block.xy[order][0] - spin_center[0], current_block.xy[order][1] - spin_center[1]]
        milimeter_delta2 = pixel_to_milimeter(delta2, ratio)

