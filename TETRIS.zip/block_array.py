import numpy as np

pieces = [[[1, 1],[1, 1]],[[0, 2, 0],[2, 2, 2]],[[0, 3, 3],[3, 3, 0]],[[4, 4, 0],[0, 4, 4]],[[5, 5, 5, 5]],[[0, 0, 6],[6, 6, 6]],[[7, 0, 0],[7, 7, 7]]]
center = [[[1,1]],[[1.5,1.5],[1.5,0.5],[1.5,0.5],[1.5,1.5]],[[1,1.5],[1.5,1]],[[1,1.5],[1.5,1]],[[0.5,2],[2,0.5]],[[1.5,2.5],[2.5,0.5],[0.5,0.5],[0.5,1.5]],[[1.5,0.5],[0.5,0.5],[0.5,2.5],[2.5,1.5]]]

#print(pieces,"\n")
def rotate(input_piece,n_times):
    i = [x[:] for x in input_piece]
    
    for _ in range(n_times):
        rows = len(i)
        cols = len(i[0])
        r = [[0]*rows for _ in range(cols)]
        
        for rs in range(rows):
            for cs in range(cols):
                #for y coordinate,downforward is positive
                r[cs][rows-rs-1] = i[rs][cs]
                # Or r[cs][rs] = i[rows-rs-1][cs]
        i = r
    return i


# pieces except 'I' and 'O' with 2 * 3 shape
pieces = pieces[1:4] + pieces[5:]

# test rotate funciton
real = []
for i in range(len(pieces)):
    all_rotate = []
    for r in range(4):
        all_rotate.append(rotate(pieces[i], r))
    pieces[i] = all_rotate
    piece_rotate = []
    for piece in pieces[i]:
        idx = 0
        index = [len(piece)]
        for r in piece:
            for ele in r:
                if ele:
                    index.append(idx)
                idx += 1
        piece_rotate.append(index)
    real.append(piece_rotate)
# print(real)

pieces = [[[1, 1],[1, 1]],[[0, 2, 0],[2, 2, 2]],[[0, 3, 3],[3, 3, 0]],[[4, 4, 0],[0, 4, 4]],[[5, 5, 5, 5]],[[0, 0, 6],[6, 6, 6]],[[7, 0, 0],[7, 7, 7]]]