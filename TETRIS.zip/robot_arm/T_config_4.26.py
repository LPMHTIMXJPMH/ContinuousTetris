# -*- coding: utf-8 -*-
"""
Created on Wed Apr 20 21:09:45 2022

@author: 魏延辉
"""

import serial
import time
import moveDir1
import moveDir新坐标


from tkinter import *
import cv2
import tkinter as tk
from PIL import Image, ImageTk  #图像控件

#第一类     #设备常量    
STROKE_X=550     #X轴行程
STROKE_Y=450     #Y轴行程
STROKE_Z=50      #Z轴行程


SCREW_PITCH_X=95    #X轴导程
SCREW_PITCH_Y=95    #Y轴行程
SCREW_PITCH_Z=10    #Z轴行程

#第二类    #驱动器


reducer_y_i=5
reducer_x_i=15

ENCODER_RESOLUTTION_400W=16777216    #编码器分辨率   #400W驱动器  24位分辨率    Pn210 760
ENCODER_RESOLUTTION_200W=1048576                    #200W驱动器  20位分辨率 Pn210 1900
ENCODER_RESOLUTTION_50W=1048756                     #50W驱动器  20位分辨率 Pn210 Z 1000 A 36000


# frequency_X=5700                      #单片机频率  
# frequency_Y=57000
# frequency_Z=5000

frequency_A=36000
frequency_X=95000                       
frequency_Y=95000
frequency_Z=20000

INSTRUCTION_X=0.125                          #X轴指令单位                      Pn20E
INSTRUCTION_Y=0.05                          #Y轴指令单位
INSTRUCTION_Z=0.01                          #Z轴指令单位
INSTRUCTION_A=0.01                           #A轴指令单位


COMNAME_XZ = "COM8"
COMNAME_YA = "COM7"
Z_UP = 45
Z_DOWN = 0
Z_MID = 3.0
little_Z=2
littleZmid=6.5

image_width = 600                     #摄像头幕布大小范围
image_height = 500


global current_X
global current_Y
global current_Z
global current_A
global Start

current_X=0
current_Y=0
current_Z=0
current_A=0

little_time=0.05

X=302
Y=150

serXZ  = serial.Serial(COMNAME_XZ, 115200)
serYA  = serial.Serial(COMNAME_YA ,115200)
# serA  = serial.Serial(COMNAME_YA ,115200)

##################################################
#改单片机频率
def setHX(frequency_X):
    # global current_X
    # if 0 <= X1 <= STROKE_X :
        # current_X=X1
        s1 = str(frequency_X)
        s2 = "HX"+s1+"E"
        time.sleep(0.1)
        serXZ.write(s2.encode('utf-8')) 
        # current_X=X1
    
def setHY(frequency_Y):
    # global current_X
    # if 0 <= X1 <= STROKE_X :
        # current_X=X1
        s1 = str(frequency_Y)
        s2 = "HY"+s1+"E"
        time.sleep(0.1)
        serYA.write(s2.encode('utf-8')) 
        
def setHZ(frequency_Z):
    # global current_X
    # if 0 <= X1 <= STROKE_X :
        # current_X=X1
        s1 = str(frequency_Z)
        s2 = "HZ"+s1+"E"
        time.sleep(0.1)
        serXZ.write(s2.encode('utf-8')) 
        
def setHA(frequency_A):
    # global current_X
    # if 0 <= X1 <= STROKE_X :
        # current_X=X1
        s1 = str(frequency_A)
        s2 = "HA"+s1+"E"
        time.sleep(0.1)
        serYA.write(s2.encode('utf-8')) 
        
        
def setfrequency(frequency_X,frequency_Y,frequency_Z,frequency_A):
    setHX(frequency_X)
    setHY(frequency_Y)
    setHZ(frequency_Z)
    setHA(frequency_A)

    



def moveX(X1 = 10.0):
    global current_X
    if 0 <= X1 <= STROKE_X :
        # current_X=X1
        s1 = str(int(X1/INSTRUCTION_X*reducer_x_i))
        s2 = "GX"+s1+"E"
        time.sleep(0.1)
        serXZ.write(s2.encode('utf-8')) 
        # current_X=X1
    else :
        print("X坐标超程")
def moveY(Y1=10.0):
    global current_Y

    if 0 <= Y1 <= STROKE_Y :
        # current_Y=Y1
        s1 = str(int(Y1/INSTRUCTION_Y*reducer_y_i))
        s2 = "GY-"+s1+"E"
        time.sleep(0.1)
        serYA.write(s2.encode('utf-8')) 
        # current_Y=Y1
       
    else :
        print("Y坐标超程")
        
# def moveA(A1=10.0):
#     global current_A
#     if -180 <= A1 <= 360:
#         # current_A=A1
#         s1= str(int(A1/INSTRUCTION_A))
#         s2 = "GA"+s1+"E"
#         time.sleep(0.1)
#         serYA.write(s2.encode('utf-8')) 
#         # time.sleep(2)
def moveA(A1=10.0):
    global current_A
    if 0 <= A1 <= 360:
        if 0 <= A1 <= 180:
            # current_A=A1
            s1= str(int(A1/INSTRUCTION_A))
            s2 = "GA"+s1+"E"
            time.sleep(0.1)
            serYA.write(s2.encode('utf-8')) 
            # time.sleep(2)
        elif 180 < A1 <= 360:
            # current_A=A1
            s1= str(-1*int((360-A1)/INSTRUCTION_A))
            s2 = "GA"+s1+"E"
            time.sleep(0.1)
            serYA.write(s2.encode('utf-8')) 
            # time.sleep(2)
        else:
         	print("A1输入有问题")
def moveZup():
    global current_Z
    s1 = str(int(Z_UP/INSTRUCTION_Z))
    s2 = "GZ"+s1+"E"
    time.sleep(0.1)
    serXZ.write(s2.encode('utf-8')) 
    serXZ.write(s2.encode('utf-8'))
    t=get_sleep_time_Z(Z_UP)
    time.sleep(t)
    time.sleep(little_time)
    current_Z=Z_UP
def moveZdown():
    global current_Z
    s1 = str(int(Z_DOWN/INSTRUCTION_Z))
    s2 = "GZ"+s1+"E"
    time.sleep(0.1)
    serXZ.write(s2.encode('utf-8'))
    t=get_sleep_time_Z(Z_DOWN)
    time.sleep(t)
    time.sleep(little_time)
    current_Z=Z_DOWN

        
def midZ():
    global current_Z
    s1 = str(int(Z_MID/INSTRUCTION_Z))
    s2 = "GZ"+s1+"E"
    time.sleep(0.1)
    serXZ.write(s2.encode('utf-8'))
    t=get_sleep_time_Z(Z_MID)
    time.sleep(t)
    time.sleep(little_time)
    current_Z=Z_MID
    
def movelittleZup():
    global current_Z
    s1 = str(int(little_Z/INSTRUCTION_Z))
    s2 = "GZ"+s1+"E"
    time.sleep(0.1)
    serXZ.write(s2.encode('utf-8')) 
    serXZ.write(s2.encode('utf-8'))
    t=get_sleep_time_Z(little_Z)
    time.sleep(t)
    time.sleep(little_time)
    current_Z=little_Z
    
def movelittleZmid():
    global current_Z
    s1 = str(int(littleZmid/INSTRUCTION_Z))
    s2 = "GZ"+s1+"E"
    time.sleep(0.1)
    serXZ.write(s2.encode('utf-8')) 
    serXZ.write(s2.encode('utf-8'))
    t=get_sleep_time_Z(littleZmid)
    time.sleep(t)
    time.sleep(little_time)
    current_Z=littleZmid
    
    

    
        
def air_open():
    s1="GUE"
    time.sleep(0.1)
    serXZ.write(s1.encode('utf-8'))
    serXZ.write(s1.encode('utf-8'))
    print("airopen")
    time.sleep(0.75)

def air_close():
    s1="GDE"
    time.sleep(0.1)
    serXZ.write(s1.encode('utf-8'))
    serXZ.write(s1.encode('utf-8'))
    print("airclose")
    time.sleep(0.5)
      
########################   X_1 Y_1 Z_1 A_1       X_10 Y_10 Z_10 A_10
def moveX_1():                           
    s1 = str(int(1/INSTRUCTION_X))
    s2 = "GX"+s1+"E"
    time.sleep(0.1)
    serXZ.write(s2.encode('utf-8')) 
def moveX_10():  
    s1 = str(int(10/INSTRUCTION_X))
    s2 = "GX"+s1+"E"
    time.sleep(0.1)
    serXZ.write(s2.encode('utf-8'))
def moveY_1():
   s1 = str(int(1/INSTRUCTION_Y*reducer_y_i))
   s2 = "GY-"+s1+"E"
   time.sleep(0.1)
   serYA.write(s2.encode('utf-8'))
def moveY_10():
   s1 = str(int(10/INSTRUCTION_Y*reducer_y_i))
   s2 = "GY-"+s1+"E"
   time.sleep(0.1)
   serYA.write(s2.encode('utf-8'))  
def moveA_1():    
   s1 = str(int(1/INSTRUCTION_A))
   s2 = "GA"+s1+"E"
   time.sleep(0.1)
   serYA.write(s2.encode('utf-8'))
def moveA_10():    
   s1 = str(int(10/INSTRUCTION_A))
   s2 = "GA"+s1+"E"
   time.sleep(0.1)
   serYA.write(s2.encode('utf-8'))
def moveZ_1(): 
    s1 = str(int(1/INSTRUCTION_Z))
    s2 = "GZ"+s1+"E"
    time.sleep(0.1)
    serXZ.write(s2.encode('utf-8'))
def moveZ_10(): 
    s1 = str(int(10/INSTRUCTION_Z))
    s2 = "GZ"+s1+"E"
    time.sleep(0.1)
    serXZ.write(s2.encode('utf-8'))
###################################################################
def Start_Point():        #回到起始坐标
    moveZup()
    move(0,0,0)
    moveZdown()
    
def get_sleep_time_X(X1):
    global current_X
    s3 = X1-current_X
    print('Xs3')
    print(s3)
    current_X=X1
    s4 = float(abs(int(s3/INSTRUCTION_X)))
    t=s4/frequency_X

    return t
    
def get_sleep_time_Y(Y1):
    global current_Y
    s3 = Y1-current_Y
    print('Ys3')
    print(s3)
    current_Y=Y1
    s4 = float(abs(int(s3/INSTRUCTION_Y*reducer_y_i)))
    t=s4/frequency_Y
    return t
def get_sleep_time_A(A1):
    global current_A
    s3 = A1-current_A
    print('As3')
    print(s3)
    current_A=A1
    s4 = float(abs(int(s3/INSTRUCTION_A)))
    t=s4/frequency_A
    return t
def get_sleep_time_Z(Z1):
    global current_Z
    s3=Z1-current_Z
    s4 = float(abs(int(s3/INSTRUCTION_Z)))
    t=s4/frequency_Z
    return t

def move_get_block_from_plate(X3,Y3,A3):    #从盘里拿
    moveZup()
    move(X3,Y3,A3)
    midZ()
    air_open()
    moveZup()
def move_put_block_from_ground(X4,Y4,A4):   #放板上
    moveZup()
    move(X4,Y4,A4)
    moveZdown()
    air_close()  
    movelittleZup()
    time.sleep(0.5) 
    moveZup()
def move_get_block_from_ground(X3,Y3,A3):  #从板上拿
    moveZup()
    move(X3,Y3,A3)
    moveZdown()
    air_open()
    moveZup()
    time.sleep(0.2) 
def move_put_block_from_plate(X4,Y4,A4):   #放盘里
    moveZup()
    move(X4,Y4,A4)
    midZ()
    air_close()
    time.sleep(0.5) 
    movelittleZmid()
    time.sleep(0.2)
    moveZup()
    
def move(X1,Y1,A1):  
    moveX(X1)
    moveY(Y1)
    moveA(A1)
    t=0.0
    print(X1)
    print(Y1)
    print(A1)
    # get_sleep_time_X(X1)
    t1=get_sleep_time_X(X1)
    print("sleep X is ")
    print(t1)
    t2=get_sleep_time_Y(Y1)
    t3=get_sleep_time_A(A1)
    print("sleep Y is ")
    print(t2)
    print("sleep A is ")
    print(t3)
    # if t1 > t2 and t1>t3 :
    #     t=t1
    #     print("X时间长")
    # elif t2>t1 and t2>t3 :
    #     t=t2
    #     print("Y时间长")
    # elif t3>t1 and t3>t2 :
    #     t=t3
    #     print("A时间长")
    t=max(t1,t2,t3)
    time.sleep(t)
    print("sleep t is ")
    print(t)
    time.sleep(little_time+0.3)
    
    
def moveXY_midZ(X1,Y1,A1):
    moveZup()
    moveX(X1)
    moveY(Y1)
    moveA(A1)
    midZ()
    t1=get_sleep_time_X(X1)
    print("sleep t1 is ")
    print(t1)
    t2=get_sleep_time_Y(Y1)
    t3=get_sleep_time_A(A1)
    if t1 > t2 and t1>t3:
        t=t1
    elif t2>t1 and t2>t3:
        t=t2
    else:
        t=t3
    time.sleep(t)
    time.sleep(little_time)
    
    
def move__upZ_XY_downZ(X1,Y1,A1):
    moveZup()
    moveX(X1)
    moveY(Y1)
    moveA(A1)
    moveZdown()
    t1=get_sleep_time_X(X1)
    print("sleep t1 is ")
    print(t1)
    t2=get_sleep_time_Y(Y1)
    t3=get_sleep_time_A(A1)
    if t1 > t2 and t1>t3:
        t=t1
    elif t2>t1 and t2>t3:
        t=t2
    else:
        t=t3
    time.sleep(t)
    time.sleep(little_time)
    
    
def move_first(X3,Y3,A3,X4,Y4,A4):
    move_get_block_from_plate(X3,Y3,A3)
    move_put_block_from_ground(X4,Y4,A4)
# def move_second(X3,Y3,A3,X4,Y4,A4):
#     move_get_block_from_ground(X4,Y4,A4)
#     move_put_block_from_plate(X3,Y3,A3)
def move_second(X3,Y3,A3,X4,Y4,A4):
    move_get_block_from_ground(X3,Y3,A3)
    move_put_block_from_plate(X4,Y4,A4)
    
def move_start():
    a=moveDir新坐标.moveDir()
    b=moveDir新坐标.moveDir()
    for i,x in zip(a,b):
        # for j,c in zip(i,x):
        centers = [(i[1]+X+20,i[0]+Y,i[2],x[3]+X,x[4]+Y,360-x[5])]
        
    # # # centers = [(489,419,90,150,180,30)]
        for centers_xya in centers:
            X3=centers_xya[0]
            Y3=centers_xya[1]
            A3=centers_xya[2]
            X4=centers_xya[3]
            Y4=centers_xya[4]
            A4=centers_xya[5]
        move_first(X3,Y3,A3,X4,Y4,A4)
        # move_second(X3,Y3,A3,X4,Y4,A4)
    move(0,0,0)
    time.sleep(1)
    moveZdown()
    
def movestart():
    a=moveDir1.moveDir1()
    b=moveDir1.moveDir1()
    for i,x in zip(a,b):
        # for j,c in zip(i,x):
        centers = [(x[0]+X,x[1]+Y,360-x[2],i[4]+X+20,i[3]+Y,i[5])]
        
    # # # centers = [(489,419,90,150,180,30)]
        for centers_xya in centers:
            X3=centers_xya[0]
            Y3=centers_xya[1]
            A3=centers_xya[2]
            X4=centers_xya[3]
            Y4=centers_xya[4]
            A4=centers_xya[5]
       
        move_second(X3,Y3,A3,X4,Y4,A4)
    move(0,0,0)
    time.sleep(1)
    moveZdown()
    
    #     # move(0,0,0)
        # time.sleep(1)
        # move_second(X3,Y3,A3,X4,Y4,A4)
        # time.sleep(1)

# moveZup()    
# move(0,0,180)  
# moveZdown()  
# move(0,0,0)  
# moveZdown() 
def point_pan():    #duidian
    moveZup()
    moveX(317)
    moveY(150)
    midZ()
# midZ()
# moveY(0)
# # moveX(0)
# setHX(95000)
# time.sleep(1)
# moveX(0)
# moveXY_100()
# move(0,0,0)
'''
centers = [(160+X,170+Y,270,-157+X+20,30+Y,290)]
    
#     # # # centers = [(489,419,90,150,180,30)]
for centers_xya in centers:
            X3=centers_xya[0]
            Y3=centers_xya[1]
            A3=centers_xya[2]
            X4=centers_xya[3]
            Y4=centers_xya[4]
            A4=centers_xya[5]
# move_first(X3,Y3,A3,X4,Y4,A4)
move_second(X3,Y3,A3,X4,Y4,A4)
# move(0,0,0)
# time.sleep(1)
# moveZdown()
'''
###############################################################GUI界面布局
#创建摄像头对象
cap = cv2.VideoCapture(1)
#界面画布更新图像
def tkImage():
    ref,frame=cap.read()
    frame = cv2.flip(frame, 1) #摄像头翻转
    cvimage = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    pilImage=Image.fromarray(cvimage)
    pilImage = pilImage.resize((image_width, image_height),Image.ANTIALIAS)
    tkImage =  ImageTk.PhotoImage(image=pilImage)
    return tkImage
def ship():
  print("打开视频")
  while True:
    pic = tkImage()
    canvas.create_image(0,0,anchor = 'nw',image = pic)
    root.update()
    root.after(1)
root = tk.Tk()
root.title('俄罗斯方块')
root.geometry('1440x900')
image_width = 600
image_height = 500
canvas = tk.Canvas(root,bg = 'white',width = image_width,height = image_height )#绘制画布
tk.Label(root,text = '摄像头视频',font = ("黑体",14),width =15,height = 1).place(x =280,y = 160)
canvas.place(x = 10,y = 200)
# tk.Button(root,text = "点此打开视频",command = ship).place(x =270,y = 55)
tk.Button(root,text='duidian',width=7,command = point_pan).place(x=20,y=130)  # 设置 button 指定 宽度 , 并且 关联 函数 , 使用表格式布局 . 
# tk.Button(root,text='取消',width=7,command = root.quit).place(x=100,y=130)
tk.Button(root,text='地到板',width=7,command = movestart).place(x=100,y=130)
tk.Button(root,text='开始',width=7,command = move_start).place(x=200,y=55)
tk.Button(root,text="开摄像头",width=7,command = ship).place(x = 270,y = 55) 
tk.Button(root,text='X_1mm',width=7,command = moveX_1).place(x=340,y=55)
tk.Button(root,text='Y_1mm',width=7,command = moveY_1).place(x=410,y=55)
tk.Button(root,text='Z_1mm',width=7,command = moveZ_1).place(x=480,y=55)
tk.Button(root,text='A_1度',width=7,command = moveA_1).place(x=550,y=55)
tk.Button(root,text='X_10mm',width=7,command = moveX_10).place(x=200,y=90)
tk.Button(root,text='Y_10mm',width=7,command = moveY_10).place(x=270,y=90)
tk.Button(root,text='A_10度',width=7,command = moveA_10).place(x=340,y=90)
tk.Button(root,text='Z_10mm',width=7,command = moveZ_10).place(x=410,y=90)
tk.Button(root,text='起始位置',width=7,command = Start_Point).place(x=480,y=90)
tk.Button(root,text='改频率',width=7,command = setfrequency(frequency_X,frequency_Y,frequency_Z,frequency_A)).place(x=550,y=90)


root.mainloop()
cap.release()
serXZ.close()
serYA.close()