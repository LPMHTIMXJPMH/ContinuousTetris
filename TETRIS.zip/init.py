import cv2 as cv
import time

import methods as methods
import Contours as Contours
import config as config

t1 = time.time()
src = cv.imread('TETRIS/frame1.jpg')
assert src is not None, print("Image has not been read!")

print("  Drawing grid board contour")
# board detect: hsv threshold value defined in methods.py file
board_hsv, res = methods.hsv(src)
board_box = Contours.findCnt(board_hsv)
assert board_box,"error on Countours.findCnt"
corners, block_size, board_vector = Contours.contour_property(8,board_box,config.Thresh,None)
print('corners of board_box\n', corners)
print('block_size\n', block_size)