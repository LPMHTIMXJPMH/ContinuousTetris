import json
import numpy as np

steps = np.zeros((34, 4))
file = open('json/indexes.json')
steps = json.load(file)
print(type(steps))
print(steps)
for i in range(34):
    steps[i] = int(steps[2*i:2*(i+1)])
