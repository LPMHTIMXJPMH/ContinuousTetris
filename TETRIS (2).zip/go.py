import numpy as np
import time
import pickle

import tetris as tetris

# gogogo
tetris = tetris.Tetris()
begin = time.time()
tetris.autoPlay()
end = time.time()

# report process
print("Mission Accomplished")
print("Remained",tetris.remained)
print(tetris.current)
print('time cost: ',end - begin)

# instore steps into json file
tetris.go = np.reshape(np.array(tetris.go), (-1,4))
#print("tetris.go")
go = tetris.go.tolist()
with open('save&reload/index_rotation_y_x.pickle', 'wb') as f:
    pickle.dump(go, f)


'''
########################################
# instore index rotation y x separately#
########################################
steps = dict()
indexes = ""
rotations = ""
ys = ""
xs = ""
for i in range(len(tetris.go)):
    #  9 -> 09
    # 11 -> 11
    indexes = indexes+str(tetris.go[i][0]) if tetris.go[i][0] > 9 else indexes+'0'+str(tetris.go[i][0])
    rotations +='0'+str(tetris.go[i][1])
    ys = ys+str(tetris.go[i][2])if tetris.go[i][2] > 9 else ys+'0'+str(tetris.go[i][2])
    xs +='0'+str(tetris.go[i][3])

steps['indexes'] = indexes
steps['rotations'] = rotations
steps['ys'] = ys
steps['xs'] = xs
print(steps)

# dump string into json file
json_steps = json.dumps(steps)
with open('json/steps_dict.json', 'w') as file:
    json.dump(json_steps, file)
    '''