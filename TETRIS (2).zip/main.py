import pickle
import os.path
import numpy as np

import tetris as tetris
import init as init
import methods
import block_array

amount = 34

# check if there is target file
gone = os.path.isfile('save&reload/index_rotation_y_x.pickle') 
if not gone:
    import go as go
    go
    target = tetris.Tetris()
    print(f'target is {target}')

# initialize board position
board_point = init.board_box
print(f'board_point is {board_point}')

# sort steps by index and then y height
with open('save&reload/index_rotation_y_x.pickle', 'rb') as f:
    steps = pickle.load(f)
print(type(steps))
print(steps)

steps = np.array(sorted(steps, key = lambda x : (x[0], x[2])))
print('steps after sorted by block piece index:\n', steps)

colors = [None]*amount
for i in range(amount):
    colors[i] = methods.random_color()
print(colors)

import Contours
src1 = Contours.where_to_draw
src2 = src1.copy()

# turn programming distance into visual distance
def position(lefttop, rightbottom, y, x):
    derivative_x = rightbottom[0] - lefttop[0]
    derivative_y = rightbottom[1] - lefttop[1]
    y = lefttop[1] + derivative_y * y
    x = lefttop[0] + derivative_x * x
    return (y, x)

block_size = init.block_size
point = init.corners['left_top']
# check if correct from step 0 -> step 34
for i in range(amount):
    y = steps[i][2]
    x = steps[i][3]
    block_idx = steps[i][0]
    rotation = steps[i][1]
    start_point = position(point, init.corners['right_bottom'], y, x)
    rotated = block_array.rotate(block_array.pieces[block_idx], rotation)
    print(start_point)
    print(rotated)

    # O I SZ LJ T
    # T
    ninety = True
    hight_diff = None

    not_niety = False
    def bias():
        pass