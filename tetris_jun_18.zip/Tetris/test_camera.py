import cv2 as cv

cap = cv.VideoCapture(0)
cap.set(3, 1920)
cap.set(4, 1080)
capture = cap.isOpened()
print('cap.isOpend()', capture)
cv.namedWindow('Window')
while(True):
    ret, frame = cap.read()
    cv.imshow('Window', frame)
    isWritten = cv.imwrite('tetris_pixel/frame2.jpg', frame)
    if isWritten:
        print('Image is successfully saved as file.')
    #if cv.waitKey(1) & 0XFF == ord('q'):
    break

cap.release()
cv.destroyAllWindows()
